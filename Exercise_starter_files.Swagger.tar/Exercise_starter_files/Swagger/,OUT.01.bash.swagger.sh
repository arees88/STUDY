demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ wget http://9a7989f3-3192-42ec-ae85-c294937d86bd.southcentralus.azurecontainer.io/swagger.json
bash: wget: command not found

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ vi swagger.json

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ ls -ltr
total 13
-rw-r--r-- 1 demouser 197121 1080 Sep  8  2020 serve.py
-rw-r--r-- 1 demouser 197121 2787 Sep  8  2020 swagger.json.git
-rw-r--r-- 1 demouser 197121  435 Sep  8  2020 swagger.sh
-rw-r--r-- 1 demouser 197121 2850 Apr  5 02:55 swagger.json

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ cat swagger.sh
# Run the swagger-ui project locally, requires docker to be installed and running
# Will pull the latest swagger-ui docker image and then will try to run it on port 80
#
# Once running, it is accessible at: http://localhost/
#
# If the user doesn't have enough permissions to use port 80, modify the local
# port to something above 8000 that is available.

docker pull swaggerapi/swagger-ui
docker run -p 80:8080 swaggerapi/swagger-ui

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ bash swagger.sh
Using default tag: latest
latest: Pulling from swaggerapi/swagger-ui
9aae54b2144e: Pulling fs layer
5df810e1c460: Pulling fs layer
a5f0adaddd54: Pulling fs layer
e6a4c36d7c0e: Pulling fs layer
345aee38d353: Pulling fs layer
29d3f97df6fd: Pulling fs layer
0950fc9d9364: Pulling fs layer
ca3e59c92b58: Pulling fs layer
707b0cf8e7fc: Pulling fs layer
1e23e54f2678: Pulling fs layer
25dd8da05791: Pulling fs layer
ce3fc08bb95f: Pulling fs layer
e6a4c36d7c0e: Waiting
345aee38d353: Waiting
29d3f97df6fd: Waiting
0950fc9d9364: Waiting
ca3e59c92b58: Waiting
707b0cf8e7fc: Waiting
1e23e54f2678: Waiting
25dd8da05791: Waiting
ce3fc08bb95f: Waiting
a5f0adaddd54: Verifying Checksum
a5f0adaddd54: Download complete
e6a4c36d7c0e: Verifying Checksum
e6a4c36d7c0e: Download complete
9aae54b2144e: Verifying Checksum
9aae54b2144e: Download complete
345aee38d353: Verifying Checksum
345aee38d353: Download complete
29d3f97df6fd: Verifying Checksum
29d3f97df6fd: Download complete
5df810e1c460: Verifying Checksum
5df810e1c460: Download complete
ca3e59c92b58: Verifying Checksum
ca3e59c92b58: Download complete
9aae54b2144e: Pull complete
1e23e54f2678: Download complete
25dd8da05791: Verifying Checksum
25dd8da05791: Download complete
707b0cf8e7fc: Verifying Checksum
707b0cf8e7fc: Download complete
0950fc9d9364: Verifying Checksum
0950fc9d9364: Download complete
ce3fc08bb95f: Verifying Checksum
ce3fc08bb95f: Download complete
5df810e1c460: Pull complete
a5f0adaddd54: Pull complete
e6a4c36d7c0e: Pull complete
345aee38d353: Pull complete
29d3f97df6fd: Pull complete
0950fc9d9364: Pull complete
ca3e59c92b58: Pull complete
707b0cf8e7fc: Pull complete
1e23e54f2678: Pull complete
25dd8da05791: Pull complete
ce3fc08bb95f: Pull complete
Digest: sha256:521efb48217365effc8bccf69c6f76a86b794a4a4f0e6996aed00bc5ed6a63de
Status: Downloaded newer image for swaggerapi/swagger-ui:latest
docker.io/swaggerapi/swagger-ui:latest

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ ls -ltr
total 13
-rw-r--r-- 1 demouser 197121 1080 Sep  8  2020 serve.py
-rw-r--r-- 1 demouser 197121 2787 Sep  8  2020 swagger.json.git
-rw-r--r-- 1 demouser 197121  435 Sep  8  2020 swagger.sh
-rw-r--r-- 1 demouser 197121 2850 Apr  5 02:55 swagger.json


demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ cp -p swagger.sh swagger.sh.git

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ vi swagger.sh

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ oo
bash: oo: command not found

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/swagger
$ bash swagger.sh
Using default tag: latest
latest: Pulling from swaggerapi/swagger-ui
Digest: sha256:521efb48217365effc8bccf69c6f76a86b794a4a4f0e6996aed00bc5ed6a63de
Status: Image is up to date for swaggerapi/swagger-ui:latest
docker.io/swaggerapi/swagger-ui:latest
172.17.0.1 - - [05/Apr/2021:03:37:49 +0000] "GET / HTTP/1.1" 200 645 "-" "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"
172.17.0.1 - - [05/Apr/2021:03:37:49 +0000] "GET /swagger-ui.css HTTP/1.1" 200 22480 "http://localhost:85/" "Mozilla/5.0 (Windos NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"
172.17.0.1 - - [05/Apr/2021:03:37:49 +0000] "GET /swagger-ui-bundle.js HTTP/1.1" 200 334080 "http://localhost:85/" "Mozilla/5.0(Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"
172.17.0.1 - - [05/Apr/2021:03:37:49 +0000] "GET /swagger-ui-standalone-preset.js HTTP/1.1" 200 104587 "http://localhost:85/" "ozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"
172.17.0.1 - - [05/Apr/2021:03:37:49 +0000] "GET /favicon-32x32.png HTTP/1.1" 200 628 "http://localhost:85/" "Mozilla/5.0 (Windws NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"


