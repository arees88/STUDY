demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files
$ ls -ltr
total 82
-rw-r--r-- 1 demouser 197121     1 Sep  8  2020 README.md
-rw-r--r-- 1 demouser 197121 19191 Sep  8  2020 aml-exercise-pipelines-with-automated-machine-learning-step.ipynb
-rw-r--r-- 1 demouser 197121  2459 Sep  8  2020 benchmark.sh
-rw-r--r-- 1 demouser 197121 53129 Sep  8  2020 bike-no.csv
-rw-r--r-- 1 demouser 197121  1149 Sep  8  2020 endpoint.py
-rw-r--r-- 1 demouser 197121   380 Sep  8  2020 logs.py
drwxr-xr-x 1 demouser 197121     0 Apr  5 02:55 Swagger/

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files
$ cd sw*
bash: cd: sw*: No such file or directory

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files
$ cd Sw*

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/Swagger
$ ls -ltr
total 13
-rw-r--r-- 1 demouser 197121 1080 Sep  8  2020 serve.py
-rw-r--r-- 1 demouser 197121 2787 Sep  8  2020 swagger.json.git
-rw-r--r-- 1 demouser 197121  435 Sep  8  2020 swagger.sh
-rw-r--r-- 1 demouser 197121 2850 Apr  5 02:55 swagger.json

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/Swagger
$ python serve.py
ls -ltr
      0 [sig] bash 1757! sigpacket::process: Suppressing signal 18 to win32 process (pid 0)
Serving HTTP on :: port 8000 (http://[::]:8000/) ...

Keyboard interrupt received, exiting.

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/Swagger
$ ls -ltr
total 14
-rw-r--r-- 1 demouser 197121 1080 Sep  8  2020 serve.py
-rw-r--r-- 1 demouser 197121 2787 Sep  8  2020 swagger.json.git
-rw-r--r-- 1 demouser 197121  435 Sep  8  2020 swagger.sh.git
-rw-r--r-- 1 demouser 197121 2850 Apr  5 02:55 swagger.json
-rw-r--r-- 1 demouser 197121  435 Apr  5 03:13 swagger.sh

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/Swagger
$ cat serve.py
"""
This script creates an HTTP server to expose the current working directory. It
is meant to be an easy way to expose a local swagger.json file so that
a swagger-ui service can pick it up from localhost.

Run it with Python3:

    $ python3 serve.py 8000

The port number is optional, defaulting to 8000. Once the server is up and
running with a swagger.json file in the same directory, then the url (assuming
port 8000) to be used in swagger-ui would be:

    http://localhost:8000/swagger.json

"""


from http.server import HTTPServer, SimpleHTTPRequestHandler, test
import sys


class CORSRequestHandler(SimpleHTTPRequestHandler):
    """
    Allows a simple HTTP server to have CORS enabled by default
    """

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        SimpleHTTPRequestHandler.end_headers(self)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Allows the port to be passed in as an argument
        port = sys.argv[-1]
    else:
        port = 8000

    test(CORSRequestHandler, HTTPServer, port=port)

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/Swagger
$ ls -ltr
total 14
-rw-r--r-- 1 demouser 197121 1080 Sep  8  2020 serve.py
-rw-r--r-- 1 demouser 197121 2787 Sep  8  2020 swagger.json.git
-rw-r--r-- 1 demouser 197121  435 Sep  8  2020 swagger.sh.git
-rw-r--r-- 1 demouser 197121 2850 Apr  5 02:55 swagger.json
-rw-r--r-- 1 demouser 197121  435 Apr  5 03:13 swagger.sh


demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/Swagger
$ python serve.py
Serving HTTP on :: port 8000 (http://[::]:8000/) ...

Keyboard interrupt received, exiting.

demouser@labvm MINGW64 ~/Desktop/nd00333_AZMLND_C2-master/Exercise_starter_files/Swagger
$ python serve.py

